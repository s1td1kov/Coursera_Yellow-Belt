#include "bus_manager.h"

using namespace std;

void BusManager::AddBus(const string &bus, const vector<string> &stops) {
    stops_for_bus[bus] = stops;
    for (const auto& stop : stops) {
        buses_for_stop[stop].push_back(bus);
    }
}

BusesForStopResponse BusManager::GetBusesForStop(const string& stop) const {
    if (buses_for_stop.count(stop) == 0) {
        return {};
    } else {
        return BusesForStopResponse{stop, buses_for_stop};
    }
}

StopsForBusResponse BusManager::GetStopsForBus(const string& bus) const {
    vector<pair<string, vector<string>>> result;
    
    if (stops_for_bus.count(bus) > 0) {
        for (const auto& stop : stops_for_bus.at(bus)) {
            result.push_back(make_pair(stop, buses_for_stop.at(stop)));
        }
    }
    return StopsForBusResponse{bus, result};
}

AllBusesResponse BusManager::GetAllBuses() const {
    return AllBusesResponse{stops_for_bus};
}
