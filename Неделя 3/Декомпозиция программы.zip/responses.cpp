#include "responses.h"

ostream& operator << (ostream& os, const BusesForStopResponse& r) {
    if (r.buses.count(r.stop) == 0) {
        os << "No stop";
    } else {
        for (const auto& bus : r.buses.at(r.stop)) {
            os << bus << " ";
        }
    }
    return os;
}

ostream& operator << (ostream& os, const StopsForBusResponse& r) {
    if (r.stops.empty()) {
        os << "No bus";
    } else {
        int i = 0;
        for (const auto& stop : r.stops) {
            ++i;
            os << "Stop " << stop.first << ":";
            if (stop.second.size() == 1) {
                os << " no interchange";
                os << endl;
            } else {
                for (const auto& bus : stop.second) {
                    if (bus != r.bus)
                        os << " " << bus;
                }
                if (i != r.stops.size())
                    os << endl;
            }
        }
    }
    return os;
}

ostream& operator << (ostream& os, const AllBusesResponse& r) {
    if (r.buses.empty()) {
        cout << "No buses";
    } else {
        int i = 0;
        for (const auto& now : r.buses) {
            ++i;
            os << "Bus " << now.first << ":";
            for (const auto& temp : r.buses.at(now.first)) {
                os << " " << temp;
            }
            if (i != r.buses.size()) {
                os << endl;
            }
        }
    }
    return os;
}
